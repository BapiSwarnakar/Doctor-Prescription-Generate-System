<?php
require_once("header.php");
if(isset($_GET['id']) && empty($_GET['id']))
{
  echo "<script>window.history.go(-1);</script>";
}
?>
<style type="text/css">
  #display_visitor_patient{
    background-color: white;
    color: black;
  }

</style>

<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Display Visitor Patient & Prescription List</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
              <li class="breadcrumb-item"><a href="javascript:void(0)" onclick="window.history.go(-1); ">All Visit Patient</a></li>
              <li class="breadcrumb-item active">Display Visitor Patient List</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- jquery validation -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">
                  <label>Select Patient</label>
                  <select name="name" class="form-control" onchange="location = this.value;" required>
                    <option value="">Select</option>
                    <?php
                     echo $server->All_Active_Patient();
                    ?>
                  </select>
                </h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body card-responsive">
                <div class="row text-center bg-danger">
                  <div class="col-md-1 col-3">
                    Digis
                  </div>
                  <div class="col-md-1 col-3">
                    Digis
                  </div>
                  <div class="col-md-6 col-4">
                    Presciption
                  </div>
                  <div class="col-md-1 col-3">
                    Advice
                  </div>
                  <div class="col-md-1 col-3">
                    Tablet
                  </div>
                  <div class="col-md-1 col-3">
                    Syrup
                  </div>
                  <div class="col-md-1 col-3">
                    Others
                  </div>
                </div>
               <div class="row">

                  <div class="col-md-1 col-6 bg-info" style="height: 500px;overflow-y: scroll; scroll-behavior: smooth;">
                      <?php
                       echo $server->All_Menu1_Digis();
                      ?>
                  </div>
                  <div class="col-md-1 col-6 bg-info" style="height: 500px;overflow-y: scroll; scroll-behavior: smooth;">
                     <?php
                       echo $server->All_Menu2_Digis();
                      ?>
                  </div>
                  
                  <div class="col-md-6 col-12 bg-primary">
                    <iframe name="Frame1" id="Frame1" src="prescription_print.php?id=<?php echo $_GET['id']; ?>" style="width: 100%;height: 100%;">
                      
                    </iframe>
                  <div class="row">
                    <div class="col-md-12 col-12 bg-warning" style="width: 100em; overflow-x: auto;white-space: nowrap; position: absolute;bottom: 0; padding: 8px;">
                      <!-- All TEST HERE SHOW -->
                        <?php
                         echo $server->All_Test();
                        ?>
                    </div>
                  </div>
                  </div>
                  <div class="col-md-1 col-4 bg-info" style="height: 500px;overflow-y: scroll; scroll-behavior: smooth;">
                     <?php
                        echo $server->All_Advice();
                      ?>
                  </div>
                  <div class="col-md-1 col-4 bg-info" style="height: 500px;overflow-y: scroll; scroll-behavior: smooth;">
                     <?php
                        echo $server->All_Tablet();
                      ?>
                  </div>
                  <div class="col-md-1 col-4 bg-info" style="height: 500px;overflow-y: scroll; scroll-behavior: smooth;">
                     <?php
                      echo $server->All_Syrup();
                     ?>
                  </div>
                  <div class="col-md-1 col-4 bg-info" style="height: 500px;overflow-y: scroll; scroll-behavior: smooth;">
                     <?php
                      echo $server->All_Others();
                     ?>
                  </div>

               </div>
               <div class="row mt-2">
                 <div class="d-flex justify-content-center col-md-11 col-12">
                    <a href="javascript:void(0)" onclick="window.history.go(-1); " class="btn btn-danger">Back</a>&nbsp;&nbsp;&nbsp;
                    <form id="Print_Prescription_form_">
                      <input type="hidden" name="id_user" id="id_user" value="<?php echo $_GET['id']; ?>">
                      <input type="hidden" name="page" value="Print_Prescription_form">
                       <input type="hidden" name="action" value="Print_Prescription_form">
                      <input type="submit" name="print" id="print" class="btn btn-success" value="Save & Print">
                    </form>
                 </div>
               </div>
             
               
              </div>
            </div>
            <!-- /.card -->
            </div>
          <!--/.col (left) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>


<!-- Modal -->
<div class="modal fade" id="generate_modal" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" >
         <form id="prescription_suggest_form"> 


        </form>
            
         
      </div>
    </div>
  </div>
</div>

 <?php
 require_once("footer.php");
 require_once("script/admin_jquery.php");
 require_once("script/search_master.php");
 ?>
 <script type="text/javascript">
   $(document).ready(function(){
    
    $('#close_sidebar').click();

     $(document).on('click','.Click_Button_for_Presc',function(event){
       var id = $(this).data('id');
       var type = $(this).data('type');
       var name = $(this).data('name');
       var user_id = '<?php echo $_GET['id']; ?>';
        if(id !='')
        {
          var form = '';
          switch (type) {
           case 'digis':
             form ='<div class="form-group col-md-12"> <label>'+name+'</label> <input type="text" name="suggest" class="form-control" id="suggest" placeholder="Suggest Now" required> <br> </div> <div class="form-group d-flex justify-content-center"> <input type="hidden" name="id" id="id" value="'+id+'"><input type="hidden" name="user_id" id="user_id" value="'+user_id+'"> <input type="hidden" name="type" id="type" value="'+type+'"><input type="hidden" name="page" value="Suggest_Submit_form"> <input type="hidden" name="action" value="Suggest_Submit_form"> <input type="submit" class="btn btn-primary btn-sm" id="submit"> </div>'; 
             break;
           case 'advice':
             form ='<div class="form-group col-md-12"> <label>'+name+'</label> <input type="text" name="suggest" class="form-control" id="suggest" placeholder="Suggest Now" required> <br> </div> <div class="form-group d-flex justify-content-center"> <input type="hidden" name="id" id="id" value="'+id+'"> <input type="hidden" name="user_id" id="user_id" value="'+user_id+'"><input type="hidden" name="type" id="type" value="'+type+'"><input type="hidden" name="page" value="Suggest_Submit_form"> <input type="hidden" name="action" value="Suggest_Submit_form"> <input type="submit" class="btn btn-primary btn-sm" id="submit"> </div>'; 
             break;
           case 'medicine':
              form ='<div class="row"> <div class="form-group col-md-6"> <label>'+name+'</label> <input type="text" name="medicine" class="form-control" id="medicine" placeholder="Medicine Quantity" required> </div> <div class="form-group col-md-6"> <label>Day</label> <input type="text" name="day" class="form-control"  id="day" placeholder="Day" required> <br> </div> <div class="form-group col-md-12 d-flex justify-content-center"> <input type="hidden" name="id" id="id" value="'+id+'"><input type="hidden" name="user_id" id="user_id" value="'+user_id+'"><input type="hidden" name="type" id="type" value="'+type+'"> <input type="hidden" name="page" value="Suggest_Submit_form"> <input type="hidden" name="action" value="Suggest_Submit_form"> <input type="submit" class="btn btn-primary btn-sm" id="submit"> </div> </div>';
            break;
           case 'test':
             form ='<div class="form-group col-md-12"> <label>'+name+'</label> <input type="text" name="suggest" class="form-control"  id="suggest" placeholder="Suggest Now" required> <br> </div> <div class="form-group d-flex justify-content-center"> <input type="hidden" name="id" id="id" value="'+id+'"><input type="hidden" name="user_id" id="user_id" value="'+user_id+'"><input type="hidden" name="type" id="type" value="'+type+'"> <input type="hidden" name="page" value="Suggest_Submit_form"> <input type="hidden" name="action" value="Suggest_Submit_form"> <input type="submit" class="btn btn-primary btn-sm" id="submit"> </div>'; 
             break;

           default:
             form ='<h1>Invalid. Not Found..!</h1>';
             break;
         } 
         $('#prescription_suggest_form').html(form);
         $('#generate_modal').modal('show');

        }
       
     });


    $('#prescription_suggest_form').parsley();
    $('#prescription_suggest_form').parsley();
    $('#prescription_suggest_form').on('submit',function(event){
    if($('#prescription_suggest_form').parsley().validate())
    {
      $.ajax({
            url:"../action-page/admin_ajax_action.php",
            method:"POST",
            enctype : "multipart/form-data",
            data: new FormData(this),
            dataType:"json",
            contentType: false,
            cache: false,
            processData:false, 
            //contentType: false,
            //cache: false,
            // processData:false,        
            beforeSend:function()
            {
              $('#submit').val('Please wait..');
              $('#submit').attr('disabled',true);
            },
            success:function(data)
            {
              if(data.success)
              {
                $('#generate_modal').modal('hide');
                //$('#').contentDocument.location.reload(true);
                window.frames["Frame1"].location.reload();
               }
               else
               {
                  toastr.options = {
                    "closeButton": true,  // true or false
                    "debug": false,
                    "newestOnTop": false,
                    "progressBar": true,  // true or false
                    "rtl": false,
                    "positionClass": "toast-top-right",
                    "preventDuplicates": false, // true or false
                    "showDuration": 300,
                    "hideDuration": 1000,
                    "timeOut": 5000,
                    "extendedTimeOut": 1000,
                    "showEasing": "swing",
                    "hideEasing": "linear",
                    "showMethod": "fadeIn",
                    "hideMethod": "fadeOut"
                  }
                  toastr["error"](data.error, "Message");
                  $('#submit').val('Submit');
                  $('#submit').attr('disabled',false);
               }
              
             }
           });
    }
   event.preventDefault();
  });



  $('#Print_Prescription_form_').on('submit',function(event){


     $.ajax({
            url:"../action-page/admin_ajax_action.php",
            method:"POST",
            enctype : "multipart/form-data",
            data: new FormData(this),
            dataType:"json",
            contentType: false,
            cache: false,
            processData:false, 
            //contentType: false,
            //cache: false,
            // processData:false,        
            beforeSend:function()
            {
              $('#print').val('Please wait..');
              $('#print').attr('disabled',true);
            },
            success:function(data)
            {
              if(data.success)
              {
                window.frames["Frame1"].window.focus();
                window.frames["Frame1"].window.print();
                $('#print').val('Save & Print');
                $('#print').attr('disabled',false); 
               }
               else
               {
                  toastr.options = {
                    "closeButton": true,  // true or false
                    "debug": false,
                    "newestOnTop": false,
                    "progressBar": true,  // true or false
                    "rtl": false,
                    "positionClass": "toast-top-right",
                    "preventDuplicates": false, // true or false
                    "showDuration": 300,
                    "hideDuration": 1000,
                    "timeOut": 5000,
                    "extendedTimeOut": 1000,
                    "showEasing": "swing",
                    "hideEasing": "linear",
                    "showMethod": "fadeIn",
                    "hideMethod": "fadeOut"
                  }
                  toastr["error"](data.error, "Message");
                  $('#print').val('Save & Print');
                  $('#print').attr('disabled',false);
               }
              
             }
           });
      
      
      event.preventDefault();
     });


   });

 </script>